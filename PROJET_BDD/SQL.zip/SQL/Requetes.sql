-- 1. 
SELECT id_Acteur, COUNT(id_Film) AS nombre_films
FROM JOUE
GROUP BY id_Acteur
HAVING COUNT(id_Film)=1;

-- 2.
SELECT id_Seance, SUM(prix) AS total_recette
FROM BILLET
GROUP BY id_Seance;

-- 3. 
SELECT COUNT(*) AS nombre_tri_dechets
FROM IMPACT_SALLE
WHERE tri_Dechets = TRUE;

-- 4.
SELECT id_Cinema, COUNT(id_Salle) AS nombre_salles
FROM SALLE
GROUP BY id_Cinema
HAVING COUNT(id_Salle) >= 3;

-- 5. 
SELECT CINEMA.id_Cinema, CINEMA.nom_Cine, SUM(IMPACT_SALLE.consommation_Energie) AS conso_totale
FROM CINEMA 
JOIN SALLE ON CINEMA.id_Cinema = SALLE.id_Cinema
JOIN IMPACT_SALLE ON SALLE.id_Salle = IMPACT_SALLE.id_Salle
GROUP BY CINEMA.id_Cinema, CINEMA.nom_Cine;

-- 6. 
SELECT AVG(valeur) AS moyenne_empreinte
FROM EMPREINTE_CARBONE;

-- 7. 
SELECT FILM.titre_Film, EMPREINTE_CARBONE.valeur AS empreinte_max
FROM FILM 
JOIN EMPREINTE_CARBONE ON FILM.id_Film = EMPREINTE_CARBONE.id_Film
ORDER BY EMPREINTE_CARBONE.valeur DESC
LIMIT 1;

-- 8. 
SELECT id_Acteur FROM ProjetBDD.JOUE J
JOIN ProjetBDD.FILM F ON J.id_Film = F.id_Film
WHERE F.genre = 'Action'
INTERSECT
SELECT id_Acteur FROM ProjetBDD.JOUE J
JOIN ProjetBDD.FILM F ON J.id_Film = F.id_Film
WHERE F.genre = 'Comedy';

