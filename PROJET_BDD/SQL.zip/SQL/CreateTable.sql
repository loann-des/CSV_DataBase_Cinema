CREATE TABLE ProjetBDD.ACTEUR (
  PRIMARY KEY (id_Acteur),
  id_Acteur      INT NOT NULL,
  nom            VARCHAR(40),
  prenom         VARCHAR(40),
  date_Naissance DATE
);

CREATE TABLE ProjetBDD.BILLET (
  PRIMARY KEY (id_Billet),
  id_Billet   INT NOT NULL,
  prix        DECIMAL(6,2),
  type_Billet VARCHAR(40),
  id_Seance   INT NOT NULL
);

CREATE TABLE ProjetBDD.CINEMA (
  PRIMARY KEY (id_Cinema),
  id_Cinema INT NOT NULL,
  nom_Cinema VARCHAR(150),
  adresse   VARCHAR(150)
);

CREATE TABLE ProjetBDD.EMPREINTE_CARBONE (
  PRIMARY KEY (id_Empreinte),
  id_Empreinte INT NOT NULL,
  sourceCarb VARCHAR(40),
  valeur DECIMAL,
  date_Mesure DATE,
  id_Film INT
);

CREATE TABLE ProjetBDD.FILM (
  PRIMARY KEY (id_Film),
  id_Film      INT NOT NULL,
  titre_Film   VARCHAR(300),
  realisateur  VARCHAR(100),
  date_Sortie DATE,
  duree        DECIMAL(6,2),
  genre        VARCHAR(100)
);

CREATE TABLE ProjetBDD.IMPACT_FILM (
  PRIMARY KEY (id_Film, id_Empreinte),
  id_Film       INT NOT NULL,
  id_Empreinte  INT NOT NULL,
  type_Impact   VARCHAR(100),
  lieu_Production VARCHAR(100)
);

CREATE TABLE ProjetBDD.IMPACT_SALLE (
  PRIMARY KEY (id_Impact_Salle),
  id_Impact_Salle      INT NOT NULL,
  consommation_Energie DECIMAL,
  tri_Dechets          BOOLEAN,
  date_Mesure          DATE,
  id_Salle             INT
);

CREATE TABLE ProjetBDD.JOUE (
  PRIMARY KEY (id_Film, id_Acteur),
  id_Film   INT NOT NULL,
  id_Acteur INT NOT NULL,
  role_Joue VARCHAR(1000)
);

CREATE TABLE ProjetBDD.SALLE (
  PRIMARY KEY (id_Salle),
  id_Salle  INT NOT NULL,
  nb_Place  INT,
  id_Cinema INT
);

CREATE TABLE ProjetBDD.SEANCE (
  PRIMARY KEY (id_Seance),
  id_Seance  INT NOT NULL,
  typeSeance VARCHAR(100),
  horaire    TIME,
  date       DATE,
  id_Salle   INT,
  id_Film    INT NOT NULL
);

ALTER TABLE ProjetBDD.BILLET 
ADD FOREIGN KEY (id_Seance) REFERENCES ProjetBDD.SEANCE (id_Seance);

ALTER TABLE ProjetBDD.EMPREINTE_CARBONE 
ADD FOREIGN KEY (id_Film) REFERENCES ProjetBDD.FILM (id_Film);

ALTER TABLE ProjetBDD.IMPACT_FILM 
ADD FOREIGN KEY (id_Empreinte) REFERENCES ProjetBDD.EMPREINTE_CARBONE (id_Empreinte);
ALTER TABLE ProjetBDD.IMPACT_FILM 
ADD FOREIGN KEY (id_Film) REFERENCES ProjetBDD.FILM (id_Film);

ALTER TABLE ProjetBDD.IMPACT_SALLE 
ADD FOREIGN KEY (id_Salle) REFERENCES ProjetBDD.SALLE (id_Salle);

ALTER TABLE ProjetBDD.JOUE 
ADD FOREIGN KEY (id_Acteur) REFERENCES ProjetBDD.ACTEUR (id_Acteur);
ALTER TABLE ProjetBDD.JOUE 
ADD FOREIGN KEY (id_Film) REFERENCES ProjetBDD.FILM (id_Film);

ALTER TABLE ProjetBDD.SALLE 
ADD FOREIGN KEY (id_Cinema) REFERENCES ProjetBDD.CINEMA (id_Cinema);

ALTER TABLE ProjetBDD.SEANCE 
ADD FOREIGN KEY (id_Film) REFERENCES ProjetBDD.FILM (id_Film);
ALTER TABLE ProjetBDD.SEANCE 
ADD FOREIGN KEY (id_Salle) REFERENCES ProjetBDD.SALLE (id_Salle);

